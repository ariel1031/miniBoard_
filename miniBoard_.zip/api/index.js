const express = require('express') //node.js에서 require() 함수는 모듈을 가지고 온다. require()는 module.exports를 리턴함. express는
const cors = require('cors')
const app = express() ////app은 express의 인스턴스이다.
const fs = require('fs') //파일 모듈을 불러오는 코드
const crypto = require('crypto')

app.use(express.json())
app.use(cors())

app.get('/', function (req, res) {
    const data = fs.readFileSync('data/board.json').toString('utf-8') //여러 게시글이 담긴 board.json 을 utf-8문자열로 data에 담기
    console.log(data)
    res.send(data) //서버에서 프론트로 보내기
})

app.post('/', function (req, res) {
    const data = JSON.parse(
        fs.readFileSync('data/board.json').toString('utf-8')
    )
    req.body.password = crypto //insertArticle, deleteArticle 함수에서 받아온 password
        .createHmac('sha256', req.body.password) //.crypto.createHmac 첫번째 인자값 'sha256' 은 알고리즘 방식 두번째 인자값은 Hmac key값.
        .digest('hex') //digest에는 어떤 인코딩 방식으로 암호화된 문자열을 표시할지를 정해줌
    data.sort((a, b) => {
        //인덱스에 따른 정렬
        return a.index - b.index //양수값 혹은 음수값이 나오겠지. 음수값이 나오면
    })
    req.body.index = data[data.length - 1].index + 1
    data.push(req.body)
    fs.writeFileSync('data/board.json', JSON.stringify(data))
    res.send({ success: true, index: req.body.index })
})

app.delete('/', function (req, res) {
    let success = false
    let errorMsg
    const data = JSON.parse(
        fs.readFileSync('data/board.json').toString('utf-8')
    )
    const index = req.body.index
    const passwordHash = crypto
        .createHmac('sha256', req.body.password)
        .digest('hex')
    const target = data.find((o) => o.index == index)
    if (target) {
        if (target.password === passwordHash) {
            data.splice(data.indexOf(target), 1)
            success = true
        } else {
            errorMsg = '비밀번호가 잘못 됨'
        }
    } else {
        errorMsg = '해당 게시물을 찾을 수 없음'
    }
    fs.writeFileSync('data/board.json', JSON.stringify(data))
    res.send({ success, errorMsg })
})

app.listen(3714)
